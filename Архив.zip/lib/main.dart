import 'package:flutter/material.dart';
import 'package:rent_app/app.dart';

void main() {
  runApp(const NoteApp());
}
