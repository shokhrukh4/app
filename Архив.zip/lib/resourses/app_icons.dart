class AppIcons {
  AppIcons._();

  static const String home = 'assets/icons/home.svg';
  static const String bed = 'assets/icons/bed.svg';
  static const String bookmark = 'assets/icons/bookmark.svg';
  static const String down = 'assets/icons/down.svg';
  static const String help = 'assets/icons/help.svg';
  static const String left = 'assets/icons/left.svg';
  static const String logout = 'assets/icons/logout.svg';
  static const String menu = 'assets/icons/menu.svg';
  static const String messegefull = 'assets/icons/messege_full.svg';
  static const String messege = 'assets/icons/messege.svg';
  static const String nearby = 'assets/icons/nearby.svg';
  static const String note = 'assets/icons/note.svg';
  static const String notifications = 'assets/icons/notifications.svg';
  static const String person = 'assets/icons/person.svg';
  static const String search = 'assets/icons/search.svg';
  static const String setting = 'assets/icons/settings.svg';
  static const String tel = 'assets/icons/tel.svg';
}
